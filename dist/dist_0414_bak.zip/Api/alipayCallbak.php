<?php
require 'aliziApi.php';
payCallbak($_REQUEST['out_trade_no']);
?>