<?php
return array(
	'name'=>'皮革模板',
	'options'=>array(),
	'template'=>array(
		'template'=>'thin', 
		'default_color'=>array('body_bg'=>'856D35','form_bg'=>'FFFFFF','title_bg'=>'666666','button_bg'=>'EE3300','font'=>'333333','border'=>'666666','nav_bg'=>'EE3300')
	),
	'verify'=>array(
		'height'=>30,
	),
);
