<?php
return array(
	'name'=>'老套模板',
	'options'=>array(),
	'template'=>array(
		'template'=>'thin',
		'default_color'=>array('body_bg'=>'F1F1F1','form_bg'=>'FFFFFF','title_bg'=>'666666','button_bg'=>'EE3300','font'=>'333333','border'=>'CC9900','nav_bg'=>'EE3300')
	),
	'verify'=>array(
		'height'=>30,
	),
);
