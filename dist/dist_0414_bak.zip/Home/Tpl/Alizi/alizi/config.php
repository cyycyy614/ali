<?php
return array(
	'name'=>'阿狸子水晶',
	'options'=>array(),
	'template'=>array(
		'template'=>'thin', //经典alizi，紧凑thin
		'default_color'=>array('body_bg'=>'3d000f','form_bg'=>'FFFFFF','title_bg'=>'666666','button_bg'=>'EE3300','font'=>'333333','border'=>'666666','nav_bg'=>'EE3300')
	),
	'verify'=>array(
		'height'=>30,//验证码高度
	),
);
