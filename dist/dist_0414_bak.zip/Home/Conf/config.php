<?php
$config =  include("Public/Common/config.php");
return $config;
?>